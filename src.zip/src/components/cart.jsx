import './cart.css';


const  Cart = () => {
    return (
        
        <div className='shoppingCart'>
           <h1>Shopping Cart</h1>
           
           
        </div>

    )
}

export default Cart



