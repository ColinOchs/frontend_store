import "./footer.css";

const Footer  = () => {
    return (<div className="footer">
        <h2>&copy; 2022, ColinTech Industries</h2><h4><p>Developer: Colin Ochs</p></h4>
        
    </div>);
};

export default Footer;

