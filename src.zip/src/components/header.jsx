import "./header.css";

const Header  = () => {
    return (<div className="header">
    
        <h2>Cobblestone Studio</h2>
    </div>)};

export default Header;