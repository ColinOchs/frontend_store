

import "./contact.css";

const Contact = () => {

    return(
        
            <div className="contactInfo">
                <h1>Feel free to reach out to us!</h1>
            <ul>
              <li> Email: </li> 
              <li>  Phone:</li> 
              <li> Address:</li> 

              <li> Facebook:</li> 
              <li>LinkedIn:</li> 
              <li>Instagram:</li> 
            </ul>
            </div>

     
    )

};

export default Contact;